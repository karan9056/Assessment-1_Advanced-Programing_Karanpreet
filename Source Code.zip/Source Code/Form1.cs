﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace GreenBankApp
{
    public partial class Form1 : Form
    {
        private Customer currentCustomer;
        private Account selectedAccount;

        public Form1()
        {
            InitializeComponent();
            LoadCustomerTypes();
            CreateCustomer();
            LoadAccountTypes();
            LoadLogo();
            UpdateStatus("Ready");
        }

        private void LoadCustomerTypes()
        {
            cmbCustomerType.Items.Clear();
            cmbCustomerType.Items.Add("Regular Customer");
            cmbCustomerType.Items.Add("Bank Staff");
            cmbCustomerType.SelectedIndex = 0;
        }

        private void CreateCustomer()
        {
            if (cmbCustomerType.SelectedItem != null && cmbCustomerType.SelectedItem.ToString() == "Bank Staff")
            {
                currentCustomer = new BankStaff("C1002", "Karanpreet Staff", "karanpreet.staff@greenbank.com");
            }
            else
            {
                currentCustomer = new RegularCustomer("C1001", "Karanpreet Regular", "karanpreet.regular@greenbank.com");
            }
        }

        private void LoadAccountTypes()
        {
            cmbAccountType.Items.Clear();

            foreach (Account account in currentCustomer.Accounts)
            {
                cmbAccountType.Items.Add(account.AccountName);
            }

            if (cmbAccountType.Items.Count > 0)
            {
                cmbAccountType.SelectedIndex = 0;
            }
        }

        private void LoadLogo()
        {
            string firstPath = Path.Combine(Application.StartupPath, "greenbank_logo.png");
            string secondPath = Path.Combine(Application.StartupPath, "logo.png");

            if (File.Exists(firstPath))
            {
                picLogo.Image = Image.FromFile(firstPath);
                picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else if (File.Exists(secondPath))
            {
                picLogo.Image = Image.FromFile(secondPath);
                picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void cmbCustomerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            CreateCustomer();
            LoadAccountTypes();
            lstTransactions.Items.Clear();
            txtAmount.Clear();
            UpdateStatus("Customer type changed");
        }

        private void cmbAccountType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAccountType.SelectedItem == null)
            {
                return;
            }

            selectedAccount = currentCustomer.GetAccountByName(cmbAccountType.SelectedItem.ToString());
            UpdateStatus("Account selected: " + selectedAccount.AccountName);
        }

        private decimal GetAmount()
        {
            decimal amount;

            if (!decimal.TryParse(txtAmount.Text.Trim(), out amount))
            {
                UpdateStatus("Enter a valid amount");
                return -1m;
            }

            return amount;
        }

        private void AddHistory(string text)
        {
            lstTransactions.Items.Insert(0, DateTime.Now.ToString("HH:mm:ss") + " - " + text);
        }

        private void UpdateStatus(string text)
        {
            lblStatusValue.Text = text;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            if (selectedAccount == null)
            {
                UpdateStatus("Select an account");
                return;
            }

            decimal amount = GetAmount();

            if (amount <= 0)
            {
                return;
            }

            string result = selectedAccount.Deposit(amount);
            AddHistory(selectedAccount.AccountName + " - " + result + " - " + amount.ToString("$0.00"));
            UpdateStatus(result);
            txtAmount.Clear();
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            if (selectedAccount == null)
            {
                UpdateStatus("Select an account");
                return;
            }

            decimal amount = GetAmount();

            if (amount <= 0)
            {
                return;
            }

            string result = selectedAccount.Withdraw(amount, currentCustomer);
            AddHistory(selectedAccount.AccountName + " - " + result + " - " + amount.ToString("$0.00"));
            UpdateStatus(result);
            txtAmount.Clear();
        }

        private void btnInterest_Click(object sender, EventArgs e)
        {
            if (selectedAccount == null)
            {
                UpdateStatus("Select an account");
                return;
            }

            selectedAccount.CalculateInterest();
            AddHistory(selectedAccount.AccountName + " - " + selectedAccount.LastTransactionStatus);
            UpdateStatus(selectedAccount.LastTransactionStatus);
        }

        private void btnAccountInfo_Click(object sender, EventArgs e)
        {
            if (selectedAccount == null)
            {
                UpdateStatus("Select an account");
                return;
            }

            lstTransactions.Items.Insert(0, "--------------------------------------------------");
            lstTransactions.Items.Insert(0, selectedAccount.GetAccountInfo());
            lstTransactions.Items.Insert(0, currentCustomer.GetCustomerSummary());
            lstTransactions.Items.Insert(0, "Account information viewed");
            lstTransactions.Items.Insert(0, "--------------------------------------------------");

            UpdateStatus("Account information displayed in history");
        }
    }
}